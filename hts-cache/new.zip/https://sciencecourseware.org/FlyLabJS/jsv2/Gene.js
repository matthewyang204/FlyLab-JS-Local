function Gene(chromNum, index, mapVal, isWT, isDom, isLethal) {
   this.chromNum = chromNum;
   this.index = index;
   this.mapVal = mapVal;
   this.isWT = isWT;
   this.isDom = isDom;
   this.isLethal = isLethal;
}